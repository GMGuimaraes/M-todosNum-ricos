
#include "MatAlgebra.h"

float* resolveSistTriangSuperior(float** A, float* b, int n);
float* resolveSistTriangInferior(float** A, float* b, int n);

int main(){

	MatAlgebra g; //Criando um objeto para usar os m�todos do MatAlgebra
	
	//Criar Ler Matrizes L e U e o vetor b
	int n = 4;
	float** L = g.criaMatriz(n,n);
	float** U = g.criaMatriz(n,n);
	float* b = g.criaVetor(n);
	g.leDados(L, b, "MatL.in");	
	g.leDados(U, b, "MatU.in");	
	
	//resolver Lw=b
	float* w = resolveSistTriangInferior(L, b, n);
	
	//resolver Ux=w
	float* x = resolveSistTriangSuperior(U, w, n);

	g.imprimeVetor("w", w, n);
	g.imprimeVetor("x", x, n);
	
}

//m�todo para resolver sistema linear superior
float* resolveSistTriangSuperior(float** A, float* b, int n){
	MatAlgebra g;
	float* x = g.criaVetor(n);
	
	//para cada Xi. Iniciando pelo Xn
	for(int i=n-1; i>=0 ;i--){
		float s = 0;
		for(int j=i+1; j<n; j++){ //Somat�rio
			s = s + A[i][j]*x[j];
		}		
		x[i] = (b[i] - s)/A[i][i];
	}
	
	return x;
}

//m�todo para resolver sistema linear Inferior
float* resolveSistTriangInferior(float** A, float* b, int n){
	MatAlgebra g;
	float* x = g.criaVetor(n);
	
	//para cada Xi. Iniciando pelo X1
	for(int i=0; i<n; i++){
		float s = 0;
		for(int j=0; j<i; j++){ //Somat�rio
			s = s + A[i][j]*x[j];
		}		
		x[i] = (b[i] - s)/A[i][i];
	}
	
	return x;
}
