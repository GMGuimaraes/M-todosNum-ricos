
#include "MatAlgebra.h"

float* JacobiRichardson(float** A, float* b, int n, float err);

void copiarVetorParaColunaMatriz(float* x, float** A, int n, int i);
float* vetorColunaMatrizI(int n, int j);

int MAX_IT=50;

int main(){

	MatAlgebra g; //Criando um objeto para usar os m�todos do MatAlgebra
	
	int n = 4;
	float** A = g.criaMatriz(n,n);
	g.leDados(A, "ExMatriz.in");	

	g.imprimeMatriz("A", A, n, n);
	
	float** Ainv = g.criaMatriz(n,n);
	
	for(int i=0; i<n; i++){
	
		float* bi = vetorColunaMatrizI(n, i);
		g.imprimeVetor("bi", bi, n);
		//Soluciona Sistema linear
		float* xi = JacobiRichardson(A, bi, n, 0.0000001);
		
		copiarVetorParaColunaMatriz(xi, Ainv, n, i);
	}
	g.imprimeMatriz("Ainv", Ainv, n, n);
	
	float** I = g.multiplica(A, Ainv, n);
	
	g.imprimeMatriz("I", I, n, n);
}

//Copia o vetor x para a coluna i da matriz A
void copiarVetorParaColunaMatriz(float* x, float** A, int n, int i){
	for(int k=0; k<n; k++){
		A[k][i] = x[k];
	}
}

//retorna a coluna j da matriz identidade de tamanho n
float* vetorColunaMatrizI(int n, int j){
	MatAlgebra g;
	float* vi = g.criaVetor(n); //Criando o vetor
	g.inicializaVetor(vi, n, 0); //Zerando o vetor
	vi[j] = 1;	
	return vi;
}

// Calcula e Retorna a solu��o do sistema linear Ax=b, de dimens�o n
float* JacobiRichardson(float** A, float* b, int n, float err){
	
	MatAlgebra g; //Criando um objeto para usar os m�todos do MatAlgebra
	
	float* xk  = g.criaVetor(n); // � a solu��o no passo k
	float* xk1 = g.criaVetor(n); // � a solu��o no passo k+1
	
	//Chute Inicial
	g.copiarVetor(xk, b, n);
		
	for(int k=0; k<MAX_IT; k++){ //n�mero m�ximo de itera��es
		for(int r=0; r<n; r++){ //para cada equa��o do sistema (linha da matriz)
			xk1[r] = b[r];
			for(int j=0; j<n; j++){ //para cada coluna
				if(r!=j) 
					xk1[r] = xk1[r] - A[r][j]*xk[j];	 
			}
			xk1[r] = xk1[r]/A[r][r];
		}
		//printf("\n*** %d ***", k);
		//g.imprimeVetor("xk", xk1, n);
		
		if(g.testErroRelativo(xk, xk1, n, err))
			break; //Chegou na precis�o desejada
	
		g.copiarVetor(xk, xk1, n); //copiar xk1 para xk para ir para o pr�ximo passo
	}
	return xk1;
}
