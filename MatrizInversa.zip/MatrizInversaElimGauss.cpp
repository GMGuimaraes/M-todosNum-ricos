
#include "MatAlgebra.h"

void eliminacaoGauss(float** A, float* b, int n);
float* resolveSistTriangSuperior(float** A, float* b, int n);

void copiarVetorParaColunaMatriz(float* x, float** A, int n, int i);
float* vetorColunaMatrizI(int n, int j);

int main(){

	MatAlgebra g; //Criando um objeto para usar os m�todos do MatAlgebra
	
	int n = 4;
	float** A = g.criaMatriz(n,n);
	g.leDados(A, "ExMatriz.in");	

	g.imprimeMatriz("A", A, n, n);
	
	float** Ainv = g.criaMatriz(n,n);
	
	for(int i=0; i<n; i++){
	
		float* bi = vetorColunaMatrizI(n, i);
		g.imprimeVetor("bi", bi, n);
		//M�todo que transforma o sistema em Triangular Superior
		eliminacaoGauss(A, bi, n);
		//Dado que a matriz A � triangular superior. Resolve o sistema
		float* xi = resolveSistTriangSuperior(A, bi, n);
		g.imprimeVetor("xi", xi, n);
		copiarVetorParaColunaMatriz(xi, Ainv, n, i);
	}
	g.imprimeMatriz("Ainv", Ainv, n, n);
	
	float** I = g.multiplica(A, Ainv, n);
	
	g.imprimeMatriz("I", I, n, n);
}

//Copia o vetor x para a coluna i da matriz A
void copiarVetorParaColunaMatriz(float* x, float** A, int n, int i){
	for(int k=0; k<n; k++){
		A[k][i] = x[k];
	}
}

//retorna a coluna j da matriz identidade de tamanho n
float* vetorColunaMatrizI(int n, int j){
	MatAlgebra g;
	float* vi = g.criaVetor(n); //Criando o vetor
	g.inicializaVetor(vi, n, 0); //Zerando o vetor
	vi[j] = 1;	
	return vi;
}

//m�todo para resolver sistema linear superior
float* resolveSistTriangSuperior(float** A, float* b, int n){
	MatAlgebra g;
	float* x = g.criaVetor(n);
	
	//para cada Xi. Iniciando pelo Xn
	for(int i=n-1; i>=0 ;i--){
		float s = 0;
		for(int j=i+1; j<n; j++){ //Somat�rio
			s = s + A[i][j]*x[j];
		}		
		x[i] = (b[i] - s)/A[i][i];
	}
	
	return x;
}

//Implementar o m�todo para atualizar a linha i  da matriz A de acordo com a f�rmula
//linhaA(i) = linhaA(i) + linhaA(j)*c
void atualizaLinha(float** A, int n, int i, int j, float c){
	for(int k=0; k<n; k++){//percorrer as colunas da linha i
		A[i][k] = A[i][k] + A[j][k] * c;
	}
}

void eliminacaoGauss(float** A, float* b, int n){
	//Transforma a matriz A em triangular superior
	for(int j=0; j<n-1; j++){ //Passos: da coluna 0 at� a pen�ltima
		for(int i=j+1; i<n; i++){ //linha
			float c = -A[i][j]/A[j][j];
			atualizaLinha(A, n, i, j, c); //linha(i) + linha(j)*c
			b[i] = b[i] + b[j] * c;
		}
	}
}
